# GlowingJulia
Cool-looking version of the Julia set that's fun to tweak and play with! 
